const data = [
  {
    name: "Хозе-Рауль Капабланка",
    title: "Чемпион мира по шахматам",
    imgUrl: "src/images/photo.png",
  },
  {
    name: "Эммануил Ласкер",
    title: "Чемпион мира по шахматам",
    imgUrl: "src/images/photo.png",
  },
  {
    name: "Александр Алехин",
    title: "Чемпион мира по шахматам",
    imgUrl: "src/images/photo.png",
  },
  {
    name: "Арон Нимцович",
    title: "Чемпион мира по шахматам",
    imgUrl: "src/images/photo.png",
  },
  {
    name: "Рихард Рети",
    title: "Чемпион мира по шахматам",
    imgUrl: "src/images/photo.png",
  },
  {
    name: "Остап Бендер",
    title: "Гроссмейстер",
    imgUrl: "src/images/photo.png",
  },
  // {
  //   name: "Анатолий Карпов",
  //   title: "Чемпион мира по шахматам",
  //   imgUrl: "src/images/photo.png",
  // },
];

export default data;